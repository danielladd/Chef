## v1.0.6:

* [COOK-1481] - unicorn provider in application_ruby cookbook should run its restart
  command as root

## v1.0.4:

* [COOK-1572] - allow specification of 'bundle' command via attribute

## v1.0.2:

* [COOK-1360] - fix typo in README
* [COOK-1374] - use runit attribute in unicorn run script
* [COOK-1408] - use user and group from parent resource for runit
  service

## v1.0.0:

* [COOK-1247] - Initial release - relates to COOK-634.
* [COOK-1248] - special cases memcached
* [COOK-1258] - Precompile assets for Rails 3
* [COOK-1297] - Unicorn sub-resource should allow strings for 'port' attribute
